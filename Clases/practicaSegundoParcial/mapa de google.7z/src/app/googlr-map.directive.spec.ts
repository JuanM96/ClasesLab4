import { GooglrMapDirective } from './googlr-map.directive';

describe('GooglrMapDirective', () => {
  it('should create an instance', () => {
    const directive = new GooglrMapDirective();
    expect(directive).toBeTruthy();
  });
});
